public = {
    moveSpeed = 12.0,
    turnLerp  = 10.0,
    gravity   = true,
    stopDistance = 5.0,
	
	headingSign = -1.0,
    headingOffsetDeg = 0.0
}

local selfTc, selfRb
local player, playerTc

function start()
    selfTc = entity:getComponent("TransformComponent")
    if entity:hasComponent("RigidBodyComponent") then
        selfRb = entity:getComponent("RigidBodyComponent")
    else
        selfRb = entity:addComponent("RigidBodyComponent")
        selfRb.enableGravity = public.gravity
        selfRb:set_body_type("DYNAMIC")
        selfRb:set_linear_damping(0.2)
        selfRb:set_angular_damping(1.0)
    end

    local tag = entity:hasComponent("TagComponent") and entity:getComponent("TagComponent") or entity:addComponent("TagComponent")
    tag:Add(TagMask.Enemy)

    player = getEntityByName("Player")
    if player and player:hasComponent("TransformComponent") then
        playerTc = player:getComponent("TransformComponent")
    end
end

function update(dt)
    if not playerTc or not selfTc then return end

    local to = vec3(playerTc.position.x - selfTc.position.x, 0.0, playerTc.position.z - selfTc.position.z)
    local len = math.sqrt(to.x*to.x + to.z*to.z)
    if len < 1e-3 then return end
    to.x, to.z = to.x/len, to.z/len
	
	if len > public.stopDistance then
        local accel = public.moveSpeed
		physics.add_force(entity, vec3(to.x * accel, 0.0, to.z * accel), "force")
    end

    local desiredYawDeg = math.deg(atan2(to.x, -to.z))
    local yawOutDeg = public.headingSign * desiredYawDeg + (public.headingOffsetDeg or 0.0)
    if physics.set_rotation then
        physics.set_rotation(entity, vec3(0.0, math.rad(yawOutDeg), 0.0))
    end
end

function stop() end
