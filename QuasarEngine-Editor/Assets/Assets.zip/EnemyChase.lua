public = {
    moveSpeed = 6.0,
    turnLerp  = 10.0,
    gravity   = true,
    stopDistance = 2.0
}

local selfTc, selfRb
local player, playerTc

function start()
    selfTc = entity:getComponent("TransformComponent")
    if entity:hasComponent("RigidBodyComponent") then
        selfRb = entity:getComponent("RigidBodyComponent")
    else
        selfRb = entity:addComponent("RigidBodyComponent")
        selfRb.enableGravity = public.gravity
        selfRb:set_body_type("DYNAMIC")
        selfRb:set_linear_damping(1.0)
        selfRb:set_angular_damping(1.0)
    end

    local tag = entity:hasComponent("TagComponent") and entity:getComponent("TagComponent") or entity:addComponent("TagComponent")
    tag:Add(TagMask.Enemy)

    player = getEntityByName("Player")
    if player and player:hasComponent("TransformComponent") then
        playerTc = player:getComponent("TransformComponent")
    end
end

function update(dt)
    if not playerTc or not selfTc then return end

    local to = vec3(playerTc.position.x - selfTc.position.x, 0.0, playerTc.position.z - selfTc.position.z)
    local len = math.sqrt(to.x*to.x + to.z*to.z)
    if len < 1e-3 then return end
    to.x, to.z = to.x/len, to.z/len
	
	local stopDistance = public.stopDistance or 2.0
	
	if len <= stopDistance then
        physics.set_linear_velocity(entity, vec3(0.0, 0.0, 0.0))
        return
    end

    local vx, vz = to.x * public.moveSpeed, to.z * public.moveSpeed
    physics.set_linear_velocity(entity, vec3(vx, 0.0, vz))

    local desiredYaw = math.deg(atan2(to.x, -to.z))
    local rot = selfTc.rotation
    local curYaw = math.deg(rot.y)
    local newYaw = curYaw + (desiredYaw - curYaw) * math.min(1.0, public.turnLerp * dt)
    selfTc.rotation = vec3(0.0, math.rad(newYaw), 0.0)
end

function stop() end
